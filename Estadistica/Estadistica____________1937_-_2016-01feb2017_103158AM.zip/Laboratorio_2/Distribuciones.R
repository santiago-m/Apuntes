
#GENERACI�N DE DATOS ALEATORIOS- REPRESENTACIONES GR�FICAS DE LAS DISTRIBUCIONES#
#################################################################################


# La generaci�n de datos aleatorios se realiza con la funci�n r seguida del nombre
# de la distribuci�n de la cual se desea generar, dando los par�metros respectivos.
########################### Distribuci�n normal (rnorm)#############

win.graph(width=8,height=5) # para abrir una ventana gr�fica, conviene hacerlo siempre antes de pedir un gr�fico.
par(mfrow=c(2,3),font=2,font.lab=4,font.axis=2,las=1)# permite compartir la ventana en filas y columnas.
 
z<-rnorm(10000,6,2);z # genera un vector  con 10000 n�meros aleatorios de una normal con media 6 y desv�o 2
summary(z);sd(z)
T= hist(z); T
hist(z,nclass=50,col="steelblue")

hist(z,nclass=50,col="tomato",freq=F)# utiliza la densidad
 dz<-seq(min(z),max(z),0.001)
 lines(dnorm(dz,6,2)~dz,type="l",lwd=3)# para sobreponer la funci�n de densidad normal al histograma


 x<-rnorm(1000,15,3)# box plot de x
 fac<-gl(4,250) # Crea un factor con 4 niveles de longitud 250
 boxplot(x)
 boxplot(x~fac,col=2:5,lwd=2)

##################################################################################################################
##Las funciones ddistribution , pdistribution y qdistribution devuelven los valores de
las funciones de densidad y de distribuci�n y los cuantiles, respectivamente, seg�n la ley
distribuci�n.
#################################################################################################################

pt(2,27)# P(X<2) donde X se distribuye como una t_Student con 27 grados de libertad
pnorm(4,2,1)#P(X<4) con X normal con mu=2 y sigma=1

qnorm(0.975,0,1)# Devuelve el cuantil, es decir el valor de a/ P(X<a)=0,975



####################################################################
############## Distribuci�n exponencial (rexp)##############################
#####################################################################
win.graph(width=8,height=5)
par(mfrow=c(2,3),font=2,font.lab=4,font.axis=2,las=1)
 w<-rexp(10000,6);w
 hist(w)
 hist(w,nclass=50,col="steelblue")

 hist(w,nclass=50,col="green",freq=F)
 dw<-seq(min(w),max(w),0.001)
 lines(dexp(dw,6)~dw,type="l",lwd=3)


 w<-rexp(1000,2)
 fac<-gl(4,250) # factor con 4 niveles de longitud 250
 boxplot(w)
 boxplot(w~fac,col=2:5,lwd=2)

##################################### Distribuci�n chi-cuadrado#####################################################
win.graph(width=8,height=5)
par(mfrow=c(2,3),font=2,font.lab=4,font.axis=2,las=1)
 M<-rchisq(10000,6);M
 hist(M)
 hist(M,nclass=50,col="steelblue")

 hist(M,nclass=50,col="green",freq=F)
 dM<-seq(min(M),max(M),0.001)
 lines(dchisq(dM,6)~dM,type="l",lwd=3)


 M<-rexp(1000,2)
 fac<-gl(4,250) # factor con 4 niveles de longitud 250
 boxplot(M)
 boxplot(M~fac,col=2:5,lwd=2)

####################################################################################################################

#Ejemplo para generar 1000 muestras de tama�o 30 con distribuci�n uniforme en [0;1]
n=1
w=1;1000
while(n<=1000)
(vector<-runif(30,0,1))&(w[n]=mean(vector))&(n=n+1)
hist(w, col= "orangered3")

########################################################################################
#######################  C�DIGOS PARA INGRESAR LAS DISTRIBUCIONES #######################
#rbinom(n,size,p)
#Poisson
rpois(n, lambda)
# algunas distribuciones
#Continuas
#Uniforme
runif(n,a,b)
#Exponencial
rexp(n,beta)
#Gamma
rgamma(n, alpha, beta)
#Weibull
rweibull(n,alpha, beta)
#Beta
rbeta(n, alpha,beta)
#Normal
rnorm(n, mu, sigma)

#######################################################################################
