# Este programa hace el gr�fico de BARRAS MULTIPLES para tablas de contingencia

#Los colores se pueden asignar por numeros o con su nombre en ingl�s.
#Por ejemplo:  El nro 4 es el color azul, el 7 amarillo y el 3 verde.
#Se puede hacer el gr�fico por fila o por columna
###############
t=read.table("Datos_kalosha.txt",header=T)
attach(t)
list(t)

#Tabla General y Totales Marginales por Fila y Columnas
T=ftable(tomadec,sexo);T
addmargins(T)# da los totales  marginales
prop=prop.table(T)# frecuencias relativas con respecto al total general
prop

#Tablas y gr�ficos por "Sexo"
pc=prop.table(T,2) #frecuencias relativas por columna
pc

x11()
Graf1=barplot(pc, names=c("F ", "M"), xlab="Sexo",
col=c(4,5), cex.names=0.6, beside=TRUE, font=3, ylab= "Proporci�n de empleados", main="Distribuci�n de Toma de decisi�n por Sexo")
legend (3, 0.8, c("NO", "SI"), fill=c(4,5))

#Tablas y gr�ficos por "Toma de Decisiones"
T=ftable(sexo,tomadec);T
addmargins(T)# da los totales  marginales
pc=prop.table(T,2) #frecuencias relativas por columna
pc

x11()
Graf2=barplot(pc, names=c("NO", "SI"), xlab="Toma de Decisiones",ylab="Proporci�n de empleados",
col=c("yellow","orange"), cex.names=0.6, beside=TRUE, font=3, main="Distribuci�n de Sexo por Toma de decisi�n")
legend (3,0.6, c("F","M"), fill=c("yellow","orange"))
